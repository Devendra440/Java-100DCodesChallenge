"""
Java 82r – Markdown → PDF Converter
Uses fpdf2 with system Segoe UI + Consolas TTF fonts (full Unicode support).
"""

import os, re
from fpdf import FPDF, XPos, YPos

# ── Paths ────────────────────────────────────────────────────────────────────
NOTES_DIR  = os.path.dirname(os.path.abspath(__file__))
OUTPUT_PDF = os.path.join(NOTES_DIR, "Java_82r_Notes.pdf")
FONTS      = "C:/Windows/Fonts/"

# ── Sort key ─────────────────────────────────────────────────────────────────
def sort_key(fn):
    nums = re.findall(r'\d+', os.path.splitext(fn)[0])
    return tuple(int(n) for n in nums) if nums else (999999,)

md_files = sorted(
    [f for f in os.listdir(NOTES_DIR) if f.endswith('.md')],
    key=sort_key
)
print(f"Found {len(md_files)} markdown files.\n")
for i, f in enumerate(md_files, 1):
    print(f"  {i:02d}. {f}")

# ── Palette ───────────────────────────────────────────────────────────────────
DARK_BG  = (15,  52,  96)
ACCENT   = (233, 69,  96)
LIGHT_BG = (240, 244, 255)
CODE_BG  = (30,  30,  46)
CODE_FG  = (205, 214, 244)
TEXT     = (26,  26,  46)
GRAY     = (120, 120, 140)

# ── PDF class ─────────────────────────────────────────────────────────────────
class JavaPDF(FPDF):
    def setup_fonts(self):
        self.add_font("Segoe",   "",  FONTS + "segoeui.ttf")
        self.add_font("Segoe",   "B", FONTS + "segoeuib.ttf")
        self.add_font("Segoe",   "I", FONTS + "segoeuii.ttf")
        self.add_font("Segoe",   "BI",FONTS + "segoeuiz.ttf")
        self.add_font("Consolas","",  FONTS + "consola.ttf")
        self.add_font("Consolas","B", FONTS + "consolab.ttf")

    def header(self):
        if self.page_no() <= 2:   # no header on cover or TOC
            return
        self.set_font("Segoe", "B", 8)
        self.set_text_color(*GRAY)
        self.cell(0, 7, "Java 82r \u2013 Complete Notes", align="L",
                  new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.set_draw_color(*ACCENT)
        self.set_line_width(0.3)
        self.line(self.l_margin, self.get_y(),
                  self.w - self.r_margin, self.get_y())
        self.ln(2)

    def footer(self):
        if self.page_no() <= 2:
            return
        self.set_y(-13)
        self.set_font("Segoe", "", 8)
        self.set_text_color(*GRAY)
        self.cell(0, 8, f"Page {self.page_no() - 2}", align="C")

# ── Markdown renderer ─────────────────────────────────────────────────────────
def render_markdown(pdf: JavaPDF, md_text: str):
    page_w = pdf.w - pdf.l_margin - pdf.r_margin
    lines  = md_text.splitlines()
    i = 0
    in_code = False
    code_buf = []

    def flush_code(buf):
        if not buf:
            return
        pdf.set_fill_color(*CODE_BG)
        # top bar
        pdf.rect(pdf.l_margin, pdf.get_y(), page_w, 1.5, style="F")
        pdf.ln(1.5)
        for cl in buf:
            pdf.set_font("Consolas", "", 8.5)
            pdf.set_text_color(*CODE_FG)
            pdf.set_fill_color(*CODE_BG)
            pdf.set_x(pdf.l_margin + 3)
            pdf.multi_cell(page_w - 6, 4.8, cl, fill=True,
                           new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        # bottom bar
        pdf.set_fill_color(*CODE_BG)
        pdf.rect(pdf.l_margin, pdf.get_y(), page_w, 1.5, style="F")
        pdf.ln(4)
        pdf.set_text_color(*TEXT)

    def render_inline(line_txt, font_size=10):
        """Write a line with **bold**, *italic*, `code` support."""
        pattern = re.compile(r'(\*\*[^*]+?\*\*|\*[^*]+?\*|`[^`]+?`)')
        parts = pattern.split(line_txt)
        for part in parts:
            if part.startswith('**') and part.endswith('**'):
                pdf.set_font("Segoe", "B", font_size)
                pdf.set_text_color(*DARK_BG)
                txt = part[2:-2]
            elif part.startswith('*') and part.endswith('*'):
                pdf.set_font("Segoe", "I", font_size)
                pdf.set_text_color(80, 80, 130)
                txt = part[1:-1]
            elif part.startswith('`') and part.endswith('`'):
                pdf.set_font("Consolas", "", font_size - 1)
                pdf.set_text_color(214, 48, 49)
                txt = part[1:-1]
            else:
                pdf.set_font("Segoe", "", font_size)
                pdf.set_text_color(*TEXT)
                txt = part
            pdf.write(5.5, txt)
        pdf.ln(6)
        pdf.set_text_color(*TEXT)
        pdf.set_font("Segoe", "", 10)

    while i < len(lines):
        line = lines[i]

        # ── Code fence ────────────────────────────────────────────
        if line.strip().startswith('```'):
            if not in_code:
                in_code  = True
                code_buf = []
            else:
                flush_code(code_buf)
                in_code  = False
                code_buf = []
            i += 1
            continue

        if in_code:
            code_buf.append(line)
            i += 1
            continue

        stripped = line.strip()

        # ── HR ────────────────────────────────────────────────────
        if re.match(r'^(-{3,}|\*{3,}|_{3,})$', stripped):
            pdf.set_draw_color(*ACCENT)
            pdf.set_line_width(0.4)
            y = pdf.get_y() + 2
            pdf.line(pdf.l_margin, y, pdf.w - pdf.r_margin, y)
            pdf.ln(6)
            i += 1
            continue

        # ── Headings ──────────────────────────────────────────────
        m = re.match(r'^(#{1,6})\s+(.*)', stripped)
        if m:
            level = len(m.group(1))
            txt   = m.group(2).strip()
            if level == 1:
                pdf.ln(4)
                pdf.set_font("Segoe", "B", 16)
                pdf.set_text_color(*DARK_BG)
                pdf.multi_cell(0, 9, txt, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                y = pdf.get_y()
                pdf.set_draw_color(*ACCENT)
                pdf.set_line_width(0.7)
                pdf.line(pdf.l_margin, y, pdf.w - pdf.r_margin, y)
                pdf.ln(4)
            elif level == 2:
                pdf.ln(3)
                pdf.set_fill_color(*ACCENT)
                pdf.rect(pdf.l_margin, pdf.get_y(), 3.5, 9, style="F")
                pdf.set_x(pdf.l_margin + 6)
                pdf.set_font("Segoe", "B", 13)
                pdf.set_text_color(*DARK_BG)
                pdf.multi_cell(page_w - 6, 9, txt,
                               new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                pdf.ln(2)
            elif level == 3:
                pdf.ln(2)
                pdf.set_font("Segoe", "B", 11.5)
                pdf.set_text_color(*DARK_BG)
                pdf.multi_cell(0, 7, txt, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                pdf.ln(1)
            else:
                pdf.set_font("Segoe", "B", 10.5)
                pdf.set_text_color(*TEXT)
                pdf.multi_cell(0, 7, txt, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            i += 1
            continue

        # ── Blockquote ────────────────────────────────────────────
        if stripped.startswith('> '):
            txt = stripped[2:].strip()
            pdf.set_fill_color(*LIGHT_BG)
            pdf.set_font("Segoe", "I", 9.5)
            pdf.set_text_color(80, 80, 130)
            pdf.set_fill_color(*LIGHT_BG)
            pdf.rect(pdf.l_margin, pdf.get_y(), 3, 8, style="F")
            pdf.set_x(pdf.l_margin + 5)
            pdf.multi_cell(page_w - 5, 5.5, txt, fill=True,
                           new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.ln(2)
            pdf.set_text_color(*TEXT)
            i += 1
            continue

        # ── Unordered list ────────────────────────────────────────
        ul = re.match(r'^(\s*)[-*+] (.*)', line)
        if ul:
            indent  = len(ul.group(1))
            level   = min(indent // 2, 2)
            txt     = ul.group(2).strip()
            xoff    = pdf.l_margin + level * 6
            bullet  = "\u2022" if level == 0 else "\u25e6"
            pdf.set_x(xoff)
            pdf.set_font("Segoe", "", 10)
            pdf.set_text_color(*TEXT)
            pdf.cell(5, 5.5, bullet)
            pdf.set_x(xoff + 5)
            render_inline(txt, 10)
            # render_inline already calls ln
            i += 1
            continue

        # ── Ordered list ──────────────────────────────────────────
        ol = re.match(r'^(\d+)\.\s+(.*)', stripped)
        if ol:
            num = ol.group(1)
            txt = ol.group(2).strip()
            pdf.set_x(pdf.l_margin)
            pdf.set_font("Segoe", "B", 10)
            pdf.set_text_color(*DARK_BG)
            pdf.cell(8, 5.5, f"{num}.")
            pdf.set_x(pdf.l_margin + 8)
            render_inline(txt, 10)
            i += 1
            continue

        # ── Empty line ────────────────────────────────────────────
        if stripped == '':
            pdf.ln(3)
            i += 1
            continue

        # ── Normal paragraph ──────────────────────────────────────
        pdf.set_x(pdf.l_margin)
        render_inline(stripped, 10)
        i += 1

    if in_code and code_buf:
        flush_code(code_buf)


# ── Build PDF ─────────────────────────────────────────────────────────────────
pdf = JavaPDF(orientation="P", unit="mm", format="A4")
pdf.setup_fonts()
pdf.set_auto_page_break(auto=True, margin=20)
pdf.set_margins(18, 18, 18)

# ════════════════════════════════════════════════════════════════════════════
# COVER
# ════════════════════════════════════════════════════════════════════════════
pdf.add_page()
pdf.set_fill_color(*DARK_BG)
pdf.rect(0, 0, pdf.w, pdf.h, style="F")

# Diagonal accent block
pdf.set_fill_color(*ACCENT)
pdf.rect(0, pdf.h * 0.62, pdf.w, 6, style="F")

pdf.set_y(60)
pdf.set_font("Segoe", "B", 10)
pdf.set_text_color(*ACCENT)
pdf.cell(0, 8, "JAVA 82R BATCH", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
pdf.ln(5)

pdf.set_font("Segoe", "B", 40)
pdf.set_text_color(255, 255, 255)
pdf.cell(0, 22, "Complete", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
pdf.cell(0, 22, "Java Notes", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
pdf.ln(8)

pdf.set_font("Segoe", "", 12)
pdf.set_text_color(170, 180, 212)
pdf.cell(0, 8, f"All {len(md_files)} Topics  |  Sequential Order", align="C",
         new_x=XPos.LMARGIN, new_y=YPos.NEXT)

# ════════════════════════════════════════════════════════════════════════════
# TABLE OF CONTENTS
# ════════════════════════════════════════════════════════════════════════════
pdf.add_page()
pdf.set_fill_color(*DARK_BG)
pdf.rect(18, 18, pdf.w - 36, 16, style="F")
pdf.set_fill_color(*ACCENT)
pdf.rect(18, 18, 5, 16, style="F")
pdf.set_y(22)
pdf.set_x(28)
pdf.set_font("Segoe", "B", 14)
pdf.set_text_color(255, 255, 255)
pdf.cell(0, 10, "Table of Contents", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
pdf.ln(5)

for idx, fn in enumerate(md_files, 1):
    title = re.sub(r'^[\d_]+[\.\s]*', '', os.path.splitext(fn)[0]).strip()
    if idx % 2 == 0:
        pdf.set_fill_color(245, 247, 255)
        pdf.rect(pdf.l_margin, pdf.get_y(), pdf.w - pdf.l_margin - pdf.r_margin, 6, style="F")

    pdf.set_font("Segoe", "B", 9)
    pdf.set_text_color(*ACCENT)
    pdf.cell(8, 6, f"{idx:02d}.")
    pdf.set_font("Segoe", "", 9)
    pdf.set_text_color(*TEXT)
    pdf.cell(0, 6, title, new_x=XPos.LMARGIN, new_y=YPos.NEXT)

pdf.ln(4)

# ════════════════════════════════════════════════════════════════════════════
# CHAPTERS
# ════════════════════════════════════════════════════════════════════════════
for idx, filename in enumerate(md_files, 1):
    filepath = os.path.join(NOTES_DIR, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    title_raw   = os.path.splitext(filename)[0].strip()
    title_clean = re.sub(r'^[\d_]+[\.\s]*', '', title_raw).strip()

    pdf.add_page()

    # Chapter header band
    pdf.set_fill_color(*DARK_BG)
    pdf.rect(18, 18, pdf.w - 36, 24, style="F")
    pdf.set_fill_color(*ACCENT)
    pdf.rect(18, 18, 5, 24, style="F")

    pdf.set_y(22)
    pdf.set_x(26)
    pdf.set_font("Segoe", "", 8)
    pdf.set_text_color(*ACCENT)
    pdf.cell(0, 5, f"CHAPTER {idx}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    pdf.set_x(26)
    pdf.set_font("Segoe", "B", 13)
    pdf.set_text_color(255, 255, 255)
    pdf.multi_cell(pdf.w - 50, 8, title_clean,
                   new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    pdf.ln(6)
    pdf.set_text_color(*TEXT)
    pdf.set_font("Segoe", "", 10)

    render_markdown(pdf, content)
    print(f"  [OK] Chapter {idx:02d}: {title_raw[:65]}")

# ── Save ──────────────────────────────────────────────────────────────────────
pdf.output(OUTPUT_PDF)
print(f"\n[DONE] PDF saved to:\n   {OUTPUT_PDF}")
